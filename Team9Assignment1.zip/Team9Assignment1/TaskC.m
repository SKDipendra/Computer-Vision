function [Image] = TaskC(MyImage)
    %Task C
    %Reads the image and sets it to a variable
    Image=imread(MyImage);
    %Changes rgb image into gray 
    gray_img=rgb2gray(Image);
    % Adjusts the stretching of the histogram, dividing the scale points
    % by 255 and again adjusting to full graph i.e 0 to 255
    contrast_img = imadjust(gray_img,[0.62,0.81],[0.0,1.0]);
    
    %Selects the best value for Thresholding
    level=graythresh(gray_img);
    %Does Binarization
    binary_img=imbinarize(gray_img,level);
    %Inversion of binary image
    inverse_img = ~ binary_img;
    
    %Does Morphological opening and closing, and finally an overlay
    % Creates structuring element of disk shape 
    se=strel('Disk',7);
    %Opening and Closing
    aopen=imopen(inverse_img,se);
    aclose=imclose(inverse_img,se);
    figure;
    subplot(2,1,1);imshow(aopen);title('opening');
    subplot(2,1,2);imshow(aclose);title('closing');

    % Image overlay

    %Getting the details of desired image
    whos contrast_img;
    whos inverse_img;
    whos aopen;

    %Converting logical class to uint8 class
    aopen1=im2uint8(aopen);

    %overlaying the contrast and opening image of same clasee i.e uint8
    overlay_img=imadd(contrast_img,aopen1,'uint8');

    figure;
    subplot(2,3,1);imshow(Image);title('Orginal Image');
    subplot(2,3,2);imshow(contrast_img);title('Enhanced Image');
    subplot(2,3,3);imshow(inverse_img);title('Binary Mask');
    subplot(2,3,6);imshow(aopen);title('Opening');
    subplot(2,3,5);imshow(overlay_img);title('Overlay Image');
    % The results are satisfactory, but not good enough to be accurate. As there
    % are many spots which are white, but they are not parts of water and some
    % spots in black but they are in the water. So, the result lacks accuracy.
    % The limitation of this approach is the lack of proper sensitivity of 
    % specific parts which prevents accurate separation of objects from its
    % background.
end