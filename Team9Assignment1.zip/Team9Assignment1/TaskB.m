function [Image] = TaskB(MyImage)
    
    %Task B
    Image = imread(MyImage);
    %Converts enhanced image into binary mask
    %Changes rgb image into gray 
    gray_img=rgb2gray(Image);
    
    % Adjusts the stretching of the histogram, dividing the scale points
    % by 255 and again adjusting to full graph i.e 0 to 255
    contrast_img = imadjust(gray_img,[0.62,0.81],[0.0,1.0]);
    
    %Selects the best value for Thresholding
    level=graythresh(gray_img);
    %Does Binarization
    binary_img=imbinarize(gray_img,level);
    %Inversion of binary image
    inverse_img = ~ binary_img;

    figure;
    subplot(2,3,1);imshow(contrast_img);title('Enhanced Image');
    subplot(2,3,2);imshow(binary_img);title('Binary Mask');
    subplot(2,3,3);imshow(inverse_img);title('Inversed Binary Mask');

    %Trying with different thresholds
    % Showing the result
    % subplot(1,4,1);imshow(man_thresh);title('Manual Threshold Image');
    % The difficulty using manual thresholds was – due to unsuitable threshold
    % many spots were either too small that they were not visible or too 
    % large that they merge
    % with each other. The data interpretation was altered in this case.


end

