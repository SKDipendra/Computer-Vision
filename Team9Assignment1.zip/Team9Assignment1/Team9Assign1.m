function  Team9Assign1(MyImage)
%%calling Function TaskA
 TaskA(MyImage);
%%calling Function TaskB 
 TaskB(MyImage);
%%calling Function TaskC 
 TaskC(MyImage);
end

