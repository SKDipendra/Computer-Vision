function [Image] = TaskA(MyImage)
    %input_sat_image.jpg ImageNAme
    %Task A
    % Function that does image enhancement by contrast stretching

    %Reads the image and sets it to a variable
    Image=imread(MyImage);
    %Creates a new window to show the images
    figure;
    %Plots the image
    subplot(1,2,1); 
    %Shows the original image
    imshow(Image);
    %Sets the title of the image
    title('Orginal Image');
    %Plots and shows the histogram of the original image with its title
    subplot(1,2,2);imhist(Image); title('Histogram');
    % A histogram has appeared which is started from approx. 158 
    % and ends at approx. 215 in the horizontal axis. While it seems
    % to have a couple of high peaks in the vertical axis, it occupies
    % limited area in the horizontal axis.

    %Changes rgb image into gray 
    gray_img=rgb2gray(Image);
    % Adjusts the stretching of the histogram, dividing the scale points
    % by 255 and again adjusting to full graph i.e 0 to 255
    contrast_img = imadjust(gray_img,[0.62,0.81],[0.0,1.0]);
    %showing the histed of the orginal image
    hist_img=histeq(contrast_img);
    % Shows image and its histrogram after contrast-stretching
    figure;
    subplot(2,2,1); imshow(contrast_img); title('Streched Image');
    subplot(2,2,2); imhist(contrast_img);

    subplot(2,2,3); imshow(hist_img); title('Hist Eq Image');
    subplot(2,2,4); imhist(hist_img);

    % The histogram is now stretched from 0 to 255 in the horizontal
    % axis. While there is no change in the shape of the histogram,
    % there is change in size due to stretching. 
end

